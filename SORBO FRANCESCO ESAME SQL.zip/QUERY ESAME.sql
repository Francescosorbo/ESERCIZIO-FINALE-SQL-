/* 1 Verificare che i campi definiti come PK siano univoci.*/

select
 count(prodotto.id_prodotto) as num_righe,
 count(distinct prodotto.id_prodotto) num_righe_senza_ripetizioni
from prodotto;


/* 2 Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. */

select prodotto.nome_prodotto as prodotto, sum(vendite.prezzo) as fatturato,
year (vendite.data) as anno 
from prodotto join vendite on prodotto.id_prodotto = vendite.id_prodotto
group by year(vendite.data), prodotto 
having fatturato > 0;

/* 3 Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente*/

SELECT 
    regione.nome AS stato,
    YEAR(vendite.data) as anno,
    SUM(vendite.prezzo) AS fatturato
FROM
    regione
        JOIN
    vendite ON regione.id_regione = vendite.id_regione 
    group by regione.nome,YEAR(vendite.data)
    order by year(vendite.data) desc, fatturato desc;
    
    /* 4 Rispondere alla seguente domanda:
    qual è la categoria di articoli maggiormente richiesta dal mercato?*/
    
    
select categoria 
from (    
 SELECT 
    prodotto.categoria,
    COUNT(vendite.id_vendita) AS ArticoliRichiesti
FROM
    prodotto
        JOIN
    vendite ON prodotto.id_prodotto = vendite.id_prodotto
GROUP BY prodotto.categoria
order by ArticoliRichiesti desc) as cat
limit 1;
    
    
    /* 5 Rispondere alla seguente domanda: 
    quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. */ 

select nome_prodotto 
from (select prodotto.nome_prodotto, count(vendite.id_vendita) numero_vendita
		from prodotto left join vendite on prodotto.id_prodotto = vendite.id_prodotto
		group by nome_prodotto
		having numero_vendita=0) venduti;
                            
                            
select prodotto.nome_prodotto 
from prodotto 
where nome_prodotto not in (select prodotto.nome_prodotto
							from prodotto join vendite on prodotto.id_prodotto = vendite.id_prodotto
							group by nome_prodotto);
    
    /* 6 Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).*/

SELECT 
    prodotto.nome_prodotto, MAX(vendite.data)
FROM
    prodotto
        JOIN
    vendite ON prodotto.id_prodotto = vendite.id_prodotto
GROUP BY nome_prodotto;
   
