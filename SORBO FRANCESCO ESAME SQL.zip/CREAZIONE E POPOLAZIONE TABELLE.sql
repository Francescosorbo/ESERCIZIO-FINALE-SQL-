CREATE TABLE `toysgroup`.`prodotto` (
  `categoria` VARCHAR(45) NOT NULL,
  `id_prodotto` INT NOT NULL AUTO_INCREMENT,
  `nome_prodotto` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_prodotto`));

CREATE TABLE `toysgroup`.`regione` (
  `id_regiome` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_regiome`));

CREATE TABLE `toysgroup`.`vendite` (
  `id_vendita` INT NOT NULL AUTO_INCREMENT,
  `data` DATE NOT NULL,
  `prezzo` DECIMAL(4,2) NOT NULL,
  `id_prodotto` INT NOT NULL,
  `id_regione` INT NOT NULL,
  PRIMARY KEY (`id_vendita`),
  INDEX `vendite_prodotto_idx` (`id_prodotto` ASC) VISIBLE,
  INDEX `vendite_regione_idx` (`id_regione` ASC) VISIBLE,
  CONSTRAINT `vendite_prodotto`
    FOREIGN KEY (`id_prodotto`)
    REFERENCES `toysgroup`.`prodotto` (`id_prodotto`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `vendite_regione`
    FOREIGN KEY (`id_regione`)
    REFERENCES `toysgroup`.`regione` (`id_regiome`)
    ON DELETE CASCADE
    ON UPDATE CASCADE);



Insert into Prodotto (ID_PRODOTTO,CATEGORIA,NOME_PRODOTTO) values (1,'Giochi di società','Taboo');
Insert into Prodotto (ID_PRODOTTO,CATEGORIA,NOME_PRODOTTO) values (2,'Giochi di società','Monopoli');
Insert into Prodotto (ID_PRODOTTO,CATEGORIA,NOME_PRODOTTO) values (3,'Giochi di società','Cluedo');
Insert into Prodotto (ID_PRODOTTO,CATEGORIA,NOME_PRODOTTO) values (4,'Puzzle','Monnalisa');
Insert into Prodotto (ID_PRODOTTO,CATEGORIA,NOME_PRODOTTO) values (5,'Giochi per bambini','Barbie');
Insert into Prodotto (ID_PRODOTTO,CATEGORIA,NOME_PRODOTTO) values (6,'Giochi per bambini','Cicciobello');
Insert into Prodotto (ID_PRODOTTO,CATEGORIA,NOME_PRODOTTO) values (7,'Giochi per bambini','Masha e Orso');
Insert into Prodotto (ID_PRODOTTO,CATEGORIA,NOME_PRODOTTO) values (8,'Giochi per bambini','Trenino ');
Insert into Prodotto (ID_PRODOTTO,CATEGORIA,NOME_PRODOTTO) values (9,'Giochi di carte','Uno');
Insert into Prodotto (ID_PRODOTTO,CATEGORIA,NOME_PRODOTTO) values (10,'Giochi di carte','Carte Francesi');

Insert into REGIONE (ID_REGIONE,NOME) values (1,'Italia');
Insert into REGIONE (ID_REGIONE,NOME) values (2,'Inghilterra');
Insert into REGIONE (ID_REGIONE,NOME) values (3,'Spagna');
Insert into REGIONE (ID_REGIONE,NOME) values (4,'Germania');
Insert into REGIONE (ID_REGIONE,NOME) values (5,'Marocco');

Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (1,'2023-12-12',23.49,1,5);
Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (2,'2022-08-10',40.2,2,3);
Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (3,'2023-09-09',12.5,5,1);
Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (4,'2022-08-03',34.99,7,2);
Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (5,'2024-01-10',21.55,10,4);
Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (6,'2023-02-11',31.99,8,5);
Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (7,'2021-06-08',16.89,2,3);
Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (8,'2023-04-10',29.99,2,4);
Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (9,'2023-07-10',10.68,1,1);
Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (10,'2022-11-09',23.89,5,2);
Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (11,'2022-02-20',65.3,2,3);
Insert into VENDITE (ID_VENDITA,DATA,PREZZO,ID_PRODOTTO, ID_REGIONE) values (12,'2023-07-21',42.22,6,2);
